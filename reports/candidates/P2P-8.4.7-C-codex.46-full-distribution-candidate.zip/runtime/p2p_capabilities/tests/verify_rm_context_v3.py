"""P2P-RM-CONTEXT-01B A-Z Negative Matrix Verification.

Scenarios:
- J: CRI Conflict Resolution (Authority Precedence).
- K: Project Map Token-bound Enforcement (L0-L3).
- L: Adaptive Budget Enforcement (Hard Limit Fail-closed).
- M: CRI Applicability & Malformed Fail-closed.
- N: Symbol Retrieval AMBIGUOUS/STALE states.
- O: Secret Boundary Protection (Redaction).
- P: Bounded Fallback (No preload).
"""

import sys
import os
import pathlib
import unittest
import json
import shutil

# Setup path
sys.path.append(str(pathlib.Path(__file__).parent.parent))

from project_map import ProjectMapBuilder, LEVEL_BUDGETS
from symbol_retrieval import SymbolRetriever
from adaptive_budget import AdaptiveBudgetManager, TaskComplexity, ContextBudgetInsufficient
from contextual_rule_intelligence import CRIEngine, DomainPolicy, AuthorityLevel, RuleApplicability, PolicyEvidence, PolicyMalformedError

class TestRMContext01B(unittest.TestCase):
    def setUp(self):
        self.root = pathlib.Path("/tmp/p2p-promo01/runtime/p2p_capabilities")
        self.policy_dir = pathlib.Path("/tmp/p2p_test_policies")
        if self.policy_dir.exists():
            shutil.rmtree(self.policy_dir)
        self.policy_dir.mkdir(parents=True)

    def tearDown(self):
        if self.policy_dir.exists():
            shutil.rmtree(self.policy_dir)

    def test_scenario_j_cri_conflict(self):
        """Scenario J: CRI Authority Precedence (Owner > Project > Upstream)."""
        # P1: Upstream (Priority 30) - Deny DELETE
        p1_data = {
            "policy_id": "P1",
            "authority": "OFFICIAL_UPSTREAM",
            "priority": 30,
            "applicability": {"glob": ".*"},
            "rules": {"restricted_actions": ["DELETE"]},
            "evidence": {"source": "APR-1", "hash": "h1", "timestamp": "t1"}
        }
        
        # P2: Owner/Project (Priority 10) - Empty restricted (Allows DELETE)
        # Note: Owner (100) > Upstream (60)
        p2_data = {
            "policy_id": "P2",
            "authority": "OWNER_PROJECT",
            "priority": 10,
            "applicability": {"glob": ".*"},
            "rules": {"restricted_actions": []},
            "evidence": {"source": "APR-2", "hash": "h2", "timestamp": "t2"}
        }
        
        with open(self.policy_dir / "p1.json", "w") as f: json.dump(p1_data, f)
        with open(self.policy_dir / "p2.json", "w") as f: json.dump(p2_data, f)
        
        engine = CRIEngine(str(self.policy_dir))
        
        # Result should be ALLOWED=True because P2 (Owner) overrides P1 (Upstream)
        res = engine.check_compliance("some_file.py", "DELETE", {})
        self.assertTrue(res["allowed"])
        self.assertEqual(res["resolution"]["provenance"]["restricted_actions"]["policy_id"], "P2")

    def test_scenario_k_project_map_token_bound(self):
        """Scenario K: Project Map Token-bound Enforcement."""
        builder = ProjectMapBuilder(str(self.root))
        
        # L0 Budget is 5000. 
        l0 = builder.build_l0()
        self.assertTrue(l0.token_count <= 5000)
        
        # Test truncation if budget was tiny
        import project_map
        original_budget = project_map.LEVEL_BUDGETS[0]
        # We need to monkeypatch because it's a constant in the module
        try:
            # Note: This test assumes the builder reads from the module constant
            # In v4.3 it does.
            import project_map
            # Re-read to ensure we have access to the dictionary
            project_map.LEVEL_BUDGETS[0] = 10 
            l0_small = builder.build_l0()
            self.assertTrue(l0_small.is_truncated)
        finally:
            project_map.LEVEL_BUDGETS[0] = original_budget

    def test_scenario_l_adaptive_budget_enforcement(self):
        """Scenario L: Adaptive Budget Hard Limit Fail-closed."""
        manager = AdaptiveBudgetManager(base_budget=100)
        task = TaskComplexity(risk_class="LOW", file_count=1, max_depth=1)
        budget = manager.calculate_budget(task)
        
        # Hard limit should be small
        hard_limit = budget["hard_limit"]
        
        # Try to allocate mandatory context exceeding hard limit
        required = [{"name": "large_file", "size": hard_limit + 100}]
        with self.assertRaises(ContextBudgetInsufficient):
            manager.allocate_context(budget, required, [])

    def test_scenario_m_cri_malformed_fail_closed(self):
        """Scenario M: CRI Malformed Fail-closed."""
        # Add a malformed policy (missing authority)
        bad_data = {
            "policy_id": "BAD",
            "applicability": {"glob": "*"},
            "rules": {},
            "evidence": {"source": "X"}
        }
        with open(self.policy_dir / "bad.json", "w") as f: json.dump(bad_data, f)
        
        with self.assertRaises(PolicyMalformedError):
            CRIEngine(str(self.policy_dir))

    def test_scenario_n_symbol_retrieval_states(self):
        """Scenario N: Symbol Retrieval AMBIGUOUS/STALE states."""
        retriever = SymbolRetriever(str(self.root))
        
        # Query for a common symbol like 'MapLevel'
        res = retriever.query("MapLevel")
        self.assertIn(res["status"], ["OK", "AMBIGUOUS"])
        
        # Test STALE state by providing wrong hash
        res_stale = retriever.query("MapLevel", expected_hash="WRONG_HASH")
        self.assertEqual(res_stale["status"], "STALE")

    def test_scenario_o_secret_redaction(self):
        """Scenario O: Secret Boundary Protection."""
        manager = AdaptiveBudgetManager()
        content = "My key is sk-1234567890abcdef1234567890abcdef and pass=123456"
        redacted = manager.redact_secrets(content)
        self.assertIn("[REDACTED_SECRET]", redacted)
        self.assertNotIn("sk-1234567890", redacted)

    def test_scenario_p_bounded_fallback(self):
        """Scenario P: Bounded Fallback (No preload)."""
        builder = ProjectMapBuilder(str(self.root))
        self.assertTrue(builder.preload_blocked)
        
        # L3 build should fail if too many files requested
        with self.assertRaises(ValueError):
            builder.build_l3(["f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "f10", "f11"])

if __name__ == "__main__":
    unittest.main()
