import os
import sys
import json
import pathlib
import unittest
from typing import Any, Dict, List

# Add parent dir to path to import modules
sys.path.append(str(pathlib.Path(__file__).parent.parent))

from contextual_rule_intelligence import CRIEngine, AuthorityLevel, PolicyMalformedError

class CRIAdvancedTest(unittest.TestCase):
    def setUp(self):
        self.test_dir = pathlib.Path("/tmp/p2p_cri_adv_test")
        self.test_dir.mkdir(exist_ok=True)
        self.engine = None

    def create_policy(self, filename: str, data: Dict[str, Any]):
        with open(self.test_dir / filename, "w") as f:
            json.dump(data, f, indent=2)

    def test_authority_precedence(self):
        """Scenario M: Owner (100) with low priority vs External (20) with high priority."""
        self.create_policy("owner_policy.json", {
            "policy_id": "OWNER_01",
            "authority": "OWNER_PROJECT",
            "priority": 1,
            "applicability": {"glob": "*.py"},
            "rules": {"indent": 4, "max_line": 80},
            "evidence": {"source": "P2P-APR-001", "hash": "h1", "timestamp": "2026-08-21"}
        })
        self.create_policy("external_policy.json", {
            "policy_id": "EXT_99",
            "authority": "EXTERNAL_CORPUS",
            "priority": 999,
            "applicability": {"glob": "*.py"},
            "rules": {"indent": 2, "max_line": 120, "extra": True},
            "evidence": {"source": "web", "hash": "h2", "timestamp": "2026-08-21"}
        })
        
        engine = CRIEngine(str(self.test_dir))
        res = engine.resolve_rules("main.py")
        
        # Owner should win for 'indent' and 'max_line' despite lower priority
        self.assertEqual(res["rules"]["indent"], 4)
        self.assertEqual(res["rules"]["max_line"], 80)
        self.assertEqual(res["provenance"]["indent"]["authority"], "OWNER_PROJECT")
        
        # External rule for 'extra' should still be included as it doesn't conflict
        self.assertEqual(res["rules"]["extra"], True)
        print("Scenario M: AUTHORITY_PRECEDENCE = VERIFIED")

    def test_applicability_semantics(self):
        """Scenario §3: Dependency + Version + Task Type."""
        self.create_policy("react_policy.json", {
            "policy_id": "REACT_RULE",
            "authority": "OFFICIAL_UPSTREAM",
            "applicability": {
                "glob": "*.tsx",
                "dependencies": ["react"],
                "task_type": "refactor"
            },
            "rules": {"use_hooks": True},
            "evidence": {"source": "react-docs", "hash": "h3", "timestamp": "2026-08-21"}
        })
        
        engine = CRIEngine(str(self.test_dir))
        
        # Case 1: Match
        res = engine.resolve_rules("App.tsx", {"dependencies": ["react"], "task_type": "refactor"})
        self.assertIn("use_hooks", res["rules"])
        
        # Case 2: Wrong task type
        res = engine.resolve_rules("App.tsx", {"dependencies": ["react"], "task_type": "read"})
        self.assertNotIn("use_hooks", res["rules"])
        
        # Case 3: Missing dependency
        res = engine.resolve_rules("App.tsx", {"dependencies": ["vue"], "task_type": "refactor"})
        self.assertNotIn("use_hooks", res["rules"])
        
        print("Scenario §3: CRI_APPLICABILITY_SEMANTICS = VERIFIED")

    def test_malformed_fail_closed(self):
        """Scenario §6: Malformed Policy Fail-closed."""
        # Truncated JSON
        with open(self.test_dir / "broken.json", "w") as f:
            f.write('{"policy_id": "BROKEN",')
            
        with self.assertRaises(PolicyMalformedError):
            CRIEngine(str(self.test_dir))
        
        # Missing required field
        (self.test_dir / "broken.json").unlink()
        self.create_policy("missing_field.json", {
            "policy_id": "MISSING",
            "authority": "OWNER_PROJECT"
            # Missing rules, evidence, etc.
        })
        
        with self.assertRaises(PolicyMalformedError):
            CRIEngine(str(self.test_dir))
            
        print("Scenario §6: MALFORMED_POLICY_FAIL_CLOSED = VERIFIED")

    def test_unverified_corpus_boundary(self):
        """Scenario §7: awesome-cursor-rules-mdc direct import BLOCKED."""
        self.create_policy("awesome-cursor-rules-python.json", {
            "policy_id": "FORBIDDEN",
            "authority": "EXTERNAL_CORPUS",
            "applicability": {"glob": "*.py"},
            "rules": {"evil": True},
            "evidence": {"source": "unverified", "hash": "h4", "timestamp": "2026-08-21"}
        })
        
        engine = CRIEngine(str(self.test_dir))
        # The file should have been skipped during load
        self.assertNotIn("FORBIDDEN", engine.policies)
        print("Scenario §7: UNVERIFIED_CORPUS_BOUNDARY = VERIFIED")

    def tearDown(self):
        import shutil
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)

if __name__ == "__main__":
    unittest.main()
