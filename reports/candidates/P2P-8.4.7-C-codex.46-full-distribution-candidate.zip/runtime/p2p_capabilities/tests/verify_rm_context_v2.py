"""P2P-RM-CONTEXT-01A Negative Matrix Test.
Verifies fail-closed behavior, semantic closure, and budget enforcement.
"""

import sys
import os
import json
import pathlib
import hashlib
from dataclasses import asdict

# Ensure runtime path is available
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from project_map import ProjectMapBuilder, LEVEL_BUDGETS
from symbol_retrieval import SymbolRetriever
import adaptive_budget
from adaptive_budget import AdaptiveBudgetManager, TaskComplexity
from contextual_rule_intelligence import CRIEngine

def test_project_map_truncation():
    print("Testing Project Map Truncation (Scenario K)...")
    # Use current directory as project root
    builder = ProjectMapBuilder(".")
    
    # Mocking a tiny budget to force truncation
    import project_map
    original_budget = project_map.LEVEL_BUDGETS[0]
    project_map.LEVEL_BUDGETS[0] = 100  # Tiny budget
    
    try:
        l0 = builder.build_l0()
        print(f"L0 Truncated: {l0.is_truncated}")
        assert l0.is_truncated is True
        assert l0.token_count <= 100
    finally:
        project_map.LEVEL_BUDGETS[0] = original_budget
    print("PASS: Project Map Truncation")

def test_symbol_retrieval_stale():
    print("Testing Symbol Retrieval STALE state...")
    retriever = SymbolRetriever(".")
    # Query a known symbol in project_map.py
    res = retriever.query("ProjectMapBuilder")
    if res["status"] == "NOT_FOUND":
        print("Skipping: Symbol not found in current context")
        return
        
    correct_hash = res["results"][0]["current_hash"]
    # Query with WRONG hash
    res_stale = retriever.query("ProjectMapBuilder", expected_hash="wrong_hash")
    print(f"Symbol Status (Wrong Hash): {res_stale['status']}")
    assert res_stale["status"] == "STALE"
    print("PASS: Symbol Retrieval STALE")

def test_adaptive_budget_enforcement():
    print("Testing Adaptive Budget Enforcement (Scenario K/L)...")
    manager = AdaptiveBudgetManager(base_budget=1000)
    task = TaskComplexity(risk_class="LOW", file_count=10, max_depth=2)
    budget = manager.calculate_budget(task)
    
    required = [{"name": "req1", "size": 5000}]  # Exceeds hard limit (2160)
    try:
        manager.allocate_context(budget, required, [])
        assert False, "Should have raised ContextBudgetInsufficient"
    except adaptive_budget.ContextBudgetInsufficient:
        print("PASS: Budget Enforcement (Required > Hard)")

def test_cri_conflict_precedence():
    print("Testing CRI Conflict Precedence (Scenario M)...")
    # Create temp policy dir
    policy_dir = pathlib.Path("/tmp/p2p_policies")
    policy_dir.mkdir(exist_ok=True)
    
    p1 = {
        "policy_id": "P1",
        "scope": ".*",
        "rules": {"restricted_actions": ["DELETE"]},
        "priority": 10,
        "evidence": {"source": "APR-1", "hash": "h1"}
    }
    p2 = {
        "policy_id": "P2",
        "scope": ".*",
        "rules": {"restricted_actions": ["READ"]},
        "priority": 20,
        "evidence": {"source": "APR-2", "hash": "h2"}
    }
    
    (policy_dir / "p1.json").write_text(json.dumps(p1))
    (policy_dir / "p2.json").write_text(json.dumps(p2))
    
    engine = CRIEngine(str(policy_dir))
    res = engine.resolve_rules("any_path")
    # Higher priority (P2) should win if we were merging same keys, 
    # but here keys are different. However, get_applicable_policies should be sorted.
    policies = engine.get_applicable_policies("any_path")
    assert policies[0].policy_id == "P2"
    
    # Test compliance
    # Scenario M: P2 has higher priority (20) than P1 (10).
    # Since P2 does NOT restrict DELETE, and it overrides P1's restricted_actions key,
    # DELETE should be ALLOWED if we treat keys as atomic overrides.
    
    # In my current implementation: 
    # if key not in merged_rules: merged_rules[key] = value
    # Since P2 (highest priority) has 'restricted_actions', it sets it to ['READ'].
    # P1's 'restricted_actions' is then ignored for that key.
    
    comp = engine.check_compliance("any_path", "DELETE", {})
    assert comp["allowed"] is True
    
    # Check that READ is restricted (from P2)
    comp_read = engine.check_compliance("any_path", "READ", {})
    assert comp_read["allowed"] is False
    assert comp_read["policy_id"] == "P2"
    print("PASS: CRI Conflict Precedence")

if __name__ == "__main__":
    try:
        test_project_map_truncation()
        test_symbol_retrieval_stale()
        test_adaptive_budget_enforcement()
        test_cri_conflict_precedence()
        print("\nALL NEGATIVE MATRIX TESTS PASSED")
    except Exception as e:
        print(f"\nTEST FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
