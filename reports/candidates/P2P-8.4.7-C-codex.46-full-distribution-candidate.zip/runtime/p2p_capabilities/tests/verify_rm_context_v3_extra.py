"""P2P-RM-CONTEXT-01B Extra Verification Scenarios.

Scenarios:
- Q: Host-neutral Serialization (§9).
- R: Permission Boundary (§18).
- S: Context Result Contract (§17).
"""

import sys
import pathlib
import unittest
import json

# Setup path
sys.path.append(str(pathlib.Path(__file__).parent.parent))

from contract import ContextResult, verify_host_neutrality

class TestRMContext01BExtra(unittest.TestCase):
    def test_scenario_q_host_neutral_serialization(self):
        """Scenario Q: Host-neutral Serialization (§9)."""
        result = ContextResult(
            repository_fingerprint="repo1",
            task_fingerprint="task1",
            map_fingerprint="map1",
            selected_symbols=["sym1"],
            selected_files=["file1"],
            selected_policy_fragments=["frag1"],
            rejected_candidates=[],
            evidence_pointers=["ev1"],
            coverage_state="COMPLETE",
            budget_requested=1000,
            budget_used=500,
            cache_hit_miss="HIT",
            fallbacks=[],
            freshness="CURRENT",
            conflicts_resolution={},
            unknowns=[],
            verification_evidence="proof"
        )
        
        self.assertTrue(verify_host_neutrality(result))
        
        # Verify it's actually JSON and has sorted keys
        json_str = result.to_canonical_json()
        self.assertIn('"budget_requested": 1000', json_str)
        # Check alphabetical order of some keys
        keys = [line.strip().split(":")[0].strip('"') for line in json_str.splitlines() if ":" in line]
        self.assertEqual(keys, sorted(keys))

    def test_scenario_r_permission_boundary(self):
        """Scenario R: Permission Boundary (CONTEXT_SELECTION != EXECUTION_PERMISSION)."""
        # This is a conceptual test: verifying that selecting context does not imply execution
        # In P2P, the Context Intelligence layer only returns data, it doesn't have an 'execute' method.
        
        from contextual_rule_intelligence import CRIEngine
        # Mock a policy dir
        p_dir = pathlib.Path("/tmp/p2p_perm_test")
        p_dir.mkdir(exist_ok=True)
        
        policy = {
            "policy_id": "PERM_TEST",
            "authority": "OWNER_PROJECT",
            "applicability": {"glob": "*"},
            "rules": {"restricted_actions": ["DELETE"]},
            "evidence": {"source": "X", "hash": "h", "timestamp": "t"}
        }
        with open(p_dir / "p.json", "w") as f: json.dump(policy, f)
        
        engine = CRIEngine(str(p_dir))
        res = engine.check_compliance("test.py", "DELETE", {})
        
        # Selection works (it finds the rule)
        self.assertFalse(res["allowed"])
        
        # Proof: The engine itself cannot execute the DELETE action. 
        # It only returns "allowed: False". The caller must respect this.
        # CONTEXT_SELECTION (finding the rule) != EXECUTION_PERMISSION (the actual act).
        with self.assertRaises(AttributeError):
            engine.execute("DELETE", "test.py") # Engine has no execute method

    def test_scenario_s_result_contract(self):
        """Scenario S: Context Result Contract (§17)."""
        # Ensure all required fields are present in the dataclass
        required_fields = [
            "repository_fingerprint", "task_fingerprint", "map_fingerprint",
            "selected_symbols", "selected_files", "selected_policy_fragments",
            "rejected_candidates", "evidence_pointers", "coverage_state",
            "budget_requested", "budget_used", "cache_hit_miss", "fallbacks",
            "freshness", "conflicts_resolution", "unknowns", "verification_evidence"
        ]
        
        import dataclasses
        fields = [f.name for f in dataclasses.fields(ContextResult)]
        for f in required_fields:
            self.assertIn(f, fields)

if __name__ == "__main__":
    unittest.main()
