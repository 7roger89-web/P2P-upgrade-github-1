import sys
import os
import pathlib
import json

# Thêm đường dẫn để import p2p_capabilities
sys.path.append(str(pathlib.Path(__file__).parent.parent.parent))

from p2p_capabilities.project_map import ProjectMapBuilder
from p2p_capabilities.symbol_retrieval import SymbolRetriever
from p2p_capabilities.adaptive_budget import AdaptiveBudgetManager
from p2p_capabilities.contextual_rule_intelligence import CRIEngine

def test_project_map():
    print("Testing Project Map L0-L1...")
    root = "/tmp/p2p-promo01/runtime/p2p_capabilities"
    builder = ProjectMapBuilder(root)
    proj_map = builder.build_full_map()
    
    assert 0 in proj_map.levels
    assert 1 in proj_map.levels
    print(f"L0 Token Count: {proj_map.levels[0].token_count}")
    print(f"L1 Token Count: {proj_map.levels[1].token_count}")
    print("Project Map Test: PASS")

def test_symbol_retrieval():
    print("Testing Symbol Retrieval...")
    root = "/tmp/p2p-promo01/runtime/p2p_capabilities"
    retriever = SymbolRetriever(root)
    
    # Tìm kiếm chính mình
    results = retriever.get_symbol("SymbolRetriever")
    assert len(results) > 0
    assert "class SymbolRetriever" in results[0]["code"]
    print(f"Found symbol SymbolRetriever in {results[0]['path']}")
    print("Symbol Retrieval Test: PASS")

def test_adaptive_budget():
    print("Testing Adaptive Budget...")
    manager = AdaptiveBudgetManager(base_budget=1000)
    budget = manager.calculate_budget("COMPLEX_TASK", "ARCHITECTURE")
    
    assert budget["soft_limit"] == 3000
    assert budget["hard_limit"] == 4500
    
    # Thử phân bổ
    optional = [{"name": "L2_Map", "size": 500, "priority": 1}, {"name": "L3_Map", "size": 2000, "priority": 2}]
    res = manager.allocate_context(budget, required_size=1000, optional_items=optional)
    
    assert len(res["allocated_optional"]) == 2
    assert res["total_size"] == 3500
    assert res["budget_status"] == "SOFT_LIMIT_REACHED"
    print("Adaptive Budget Test: PASS")

def test_cri():
    print("Testing Contextual Rule Intelligence...")
    policy_dir = "/tmp/p2p_policies"
    os.makedirs(policy_dir, exist_ok=True)
    
    policy = {
        "policy_id": "P2P-POLICY-01",
        "scope": "context.py",
        "rules": {
            "restricted_actions": ["delete"],
            "required_reviewers": ["p2p_architecton"]
        },
        "priority": 100
    }
    with open(os.path.join(policy_dir, "p2p_policy_01.json"), "w") as f:
        json.dump(policy, f)
        
    engine = CRIEngine(policy_dir)
    rules = engine.get_applicable_rules("context.py")
    assert "delete" in rules["restricted_actions"]
    
    allowed, msg = engine.validate_action("context.py", "delete", {})
    assert not allowed
    print(f"CRI validation: {msg}")
    print("CRI Test: PASS")

if __name__ == "__main__":
    try:
        test_project_map()
        test_symbol_retrieval()
        test_adaptive_budget()
        test_cri()
        print("\nALL CONTEXT INTELLIGENCE TESTS: PASS")
    except Exception as e:
        print(f"\nTEST FAILED: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
